<?php

namespace OAuth2\OpenID\ResponseType;

use OAuth2\ResponseType\ResponseTypeInterface;

interface IdTokenTokenInterface extends ResponseTypeInterface
{
}
